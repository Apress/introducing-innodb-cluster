CREATE DATABASE test;
USE test;
CREATE TABLE test.t1 (id INT PRIMARY KEY, message TEXT NOT NULL);
INSERT INTO test.t1 VALUES (1, 'Chuck was here.');
