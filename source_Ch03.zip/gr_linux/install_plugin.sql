INSTALL PLUGIN group_replication SONAME 'group_replication.so';
